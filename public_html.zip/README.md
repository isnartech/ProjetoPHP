# Sistema de cadastro 🖥
Aprenda como criar um fantástico sistema com:
<br>
<ul>
  <li>Tela de Home</li>
  <li>Tela de Login</li>
  <li>Cadastro</li>
  <li>Sessões</li>
  <li>Listagem de Registros</li>
  <li>Edição de Registros</li>
  <li>Deleção de Registros</li>
  <li>Pesquisa</li>
  <li>...</li>
</ul>
<br>
Nossa playlist: https://youtube.com/playlist?list=PLSHNk_yA5fNjoIRNHV-3FprsN3NWPcnnK
