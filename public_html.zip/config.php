<?php

    $dbHost = 'Localhost';
    $dbUsername = 'u660601093_raicesta';
    $dbPassword = '@Fatalbash926';
    $dbName = 'u660601093_cestabasica';
    
    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

    // if($conexao->connect_errno)
    // {
    //     echo "Erro";
    // }
    // else
    // {
    //     echo "Conexão efetuada com sucesso";
    // }

?>